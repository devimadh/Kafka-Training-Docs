# Confluent Apache Kafka for Developers Course

This is the source code accompanying the **Confluent Apache Kafka for Developers** course.

It is organized in two subfolders `solution` and `labs`. The former contains the complete sample solution for each exercise whilst the latter contains the scaffoliding for each exercise and is meant to be used and elaborated on by the students during the hands-on.


